import db from "../MOCK_DATA.json"

function ItemCart(id) {
const item = require(db);
console.log(item.id)
  return (
    <div><p>a</p></div>
  )
}

export default ItemCart