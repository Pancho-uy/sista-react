
export default function ElSaludo() {
  return (
    <section className="secciones">
       <h2 className="seccionAnima bajoTitulo">BIENVENIDO A LA TIENDA</h2>
    </section>
  );
}